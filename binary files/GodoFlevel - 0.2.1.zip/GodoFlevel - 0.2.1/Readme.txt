This tool is still in Alpha; it's being released as a proof of concept and to gather feedback.
Item randomisation isn't compatible with the German, Spanish, or French versions of the flevel as it detects the
item string based on a hex code that spells 'Receieved "' which will change in other languages; this will be added
in the future though.

It's only been tested with the English flevel but in theory should work with any language.

The tool should be able to run on Windows 7 and higher, but let me know if you encounter
problems getting the tool to run.


////Changelog
0.2.0
-) Model/Anim Swap crash bug fixed
-) Item Swap accuracy greatly increased
-) Materia Swap added
-) Item/Materia strings updated to swapped item

Known Issues
-) Some items/Materia do not swap; some of these are due to formatting irregularities in their text,
some are due to a bug that occurs in counting texts when Materia and Items appear on the same field.


0.1.0 - Initial Release
-) Total Model/Anim Swap (bugged)
-) Rudimentary Item Swap (very inaccurate)


\\\\Instructions
Go into your FF7 installation and retrieve this file:
D:\Steam\steamapps\common\FINAL FANTASY VII\data\field\flevel.lgp
The name of this file may vary slightly if using the Spanish, French, or German versions (gflevel.lgp for instance).
*Note: The Item/Materia part will not work with languages other than English due to hex differences.

Place the default flevel.lgp into the Default File folder; keep this here as the base file for fresh randomisations.
The tool will use this file to produce a new randomised flevel each time.

Run the tool and select the options you want.
Currently, only Item/Materia Randomisation and Model/Anim Randomisation are available with no filters/parameters.
These will be added at a later date once the core of the tool is stable.

The randomised flevel.lgp will be produced in the Output File folder.
Put this back into your game files.