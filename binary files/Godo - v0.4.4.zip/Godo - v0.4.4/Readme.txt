Godo: Randomiser & Game Tuner for FF7 by Sega Chief

Build: v0.4.2 (Beta: Bugs and Errors may occur)

Description: Applies alterations to the Enemy and Character Data (Scene.bin & Kernel.bin respectively)

Randomisation Functions
) Equipment, Materia, Items, and Spells
) Starting Stats, Stat Progression, and Limit Breaks
) Enemy Models, Stats, Attacks, Names, Items, and EXP/GIL/AP
) Formation Data: Battle Background, Camera, and Enemy Quantity

Tuner Functions
) Stronger/Weaker Enemies - Does not affect HP/MP
) Max Drop/Steal Rates
) Disable Escapes
) Spellspring: All MP costs are 0
) Poverty Mode: Restricts EXP/AP/GIL
) Max AP gain

Challenge Restriction Functions
) Turns off certain commands (Physicals, Magic, etc.)



Instructions
) Before starting, make sure to right-click the .EXE and, in Properties, select Unblock if it appears.
) Whitelist in antivirus if it has trouble running/patching.
) If the randomised files crash on game launch, try a different seed; if problem persists, report it.

Instructions
For PC
) Contained within the Download is the application .EXE file and two folders; Default Files and Output Files.
) Acquire a Scene.bin and Kernel.bin from your FF7 installation and place them in the Default Files folder.

By default, the FF7 files should be (depending on version):

FF7/data/battle/scene.bin (1998/7th Heaven)
FF7/data/kernel/kernel.bin (1998/7th Heaven)

FF7/data/battle/lang-en/battle/scene.bin (2012/Steam)
FF7/data/lang-en/kernel/kernel.bin (2012/Steam)

) Run the Godo application and select the desired options.

////Options
At the top of the application window are a series of drop-down Menus.
Click into one and set the options you want and their parameters (if applicable).
Some of these parameters are %-based, some represent a range (0-25 for instance).


////Quick Options
These apply most of the changes found in the Options forms, with a predefined set of parameters.
It's primarily for speed and convenience, and behaves in a similar way to the earlier non-configurable builds of Godo.


////Profiles
A set of tailored changes that are applied to the game.
Light:
) Base player equipment/spells are unchanged, but the character stats/starting equipment are changed.
) Enemy stats are changed, but not their attacks or Model

Moderate: 
) Most spells are unchanged, but Enemy Skills, Equipment, and Items are changed.
) Character stats and starting equipment are changed.
) Enemy Stats and Attacks are changed, but Model is not swapped.

Heavy:
) Player's entire arsenal changed, along with stats, etc.
) Enemy stats and attacks randomised, with Model Swap

Extreme: Changes everything in the character/enemy data with maxed parameters
) All filters are off, everything is randomised (this will likely be unstable)


A seed can also be entered to replicate changes across different users; this requires that the same options be enabled.
If no seed is entered, one will be generated from the current System.Time.
All seeds are recorded into a notepad file within the application folder.

When ready, click Apply. If successful, a message will appear confirming this along with the seed used/created.
If an error occurs, it will appear on screen mentioning the section/location of the error.

Take the files from the Output Files folder and put them back into FF7; the game should be ready to play.
Remember that a New Game will be needed for some of the options to take effect, such as character starting stats.
A pre-existing save file can be used with the randomised files but there may be some visual glitches with the EXP gauge.


For PSX
) You will require a tool to extract files from a CD/ISO/BIN/IMG; CDMage version 1-02-1B5 is recommended.
) Open the FF7 Disc as a M2 track (not the M1 default)
) Extract the Scene + Kernel from BATTLE and INIT folders respectively
) Randomise them as per above steps

) A patch is needed to expand the Scene + Kernel space, available here: http://forums.qhimm.com/index.php?topic=11541.0
) This patch moves the Scene + Kernel to the Movies folder on the disc, allowing for unlimited space
) Once the patch is applied to the disc, import your randomised Scene + Kernel to the Movie folder.
) When prompted, confirm to pad the files with 0s.

Note: The PSX version is more prone to failure depending on what options are selected.
For stability, it is recommended not to use Model Swap and especially not Enemy Swarm.



Troubleshooting
) Bug reports should be posted here for visibility: http://forums.qhimm.com/index.php?topic=19468.0

This application was built on .NET Framework 4.7.2 and uses DotNetZip as a dependency;
it will not work on Windows XP or older.

Godo targets folders/files by name; do not rename the folders/files within the application.
The intended folders/files are:
Godo/Default Files/Scene.bin
Godo/Default Files/Kernel.bin

Godo/Output Files/Scene.bin
Godo/Output Files/Kernel.bin

Internal Error Messages
) Valid Directory Required: Make sure that the Scene.bin and Kernel.bin are in the Default Files folder and that all
file and folder names are correct. If so, and using fresh files doesn't help, report as a bug along with options.

) Scene ID: # has failed to randomise: The scene mentioned is skipped and left as default. If using default files and
this error appears, report along with options used. If modded files are used, then just proceed.

) Kernel Section: # has failed to randomise: Same as above, but for the Kernel section. Same rules apply.

) External Windows Error Message: Something has failed within the tool itself, this will be context sensitive to the
message you receive. Report it.


In-game Errors
) Game fails to launch
Sometimes randomised files will not launch with the game; if this occurs, the only way to proceed is to re-randomise on
a fresh seed and try again. This may be due to an inconsistency with the GZipping algorithm or a problem with the assigned
data that hasn't been caught yet.

) Battle fails to load/crashes on swirl: This is a formation problem, and hints at an invalid BattleBG, camera, or similar
issue. Report it as a Battle Swirl crash along with location and options.

) Battle loads but no enemies/characters: This is an invalid Enemy ID has been set to the formation.

) Battle stops but game is still running/no actions can be taken: This is a softlock and can be caused either by an attack
ID being wrong, an animation error, or similar. Context is important so try to describe what happened prior to the crash
and what enemy model was being fought.

In general, any kind of progression-blocking problem should be reported so I can more accurately update the logic/filters
to get rid of problems for the future.