Final Fantasy V: The Ancient Cave
Brute-Force Translation Patch
Version 0.6a By Sky Render

Instructions:

 Patch a headerless Final Fantasy V Japanese ROM with The Ancient Cave and
confirm that it's working.  Then patch the Final Fantasy V: The Ancient
Cave ROM you've created with this patch.  If you are applying this patch to
a previously-patched Final Fantasy V: The Ancient Cave ROM, do so at your
own risk; it's generally better to work with a fresh copy of the Japanese
version instead.

Revision History:

0.1:
* Most of the menu text is translated

0.2:
* Translated the rest of the menu text

0.3:
* Small fixes caused by spacing issues
* Monster names added
* Summon attacks translated

0.4:
* Most (but not quite all) of the relevant text is now translated
* Fixed a few issues with spaces being rendered wrong

0.5:
* Majority of relevant text translated
* More small fixes to existing translations

0.6:
* Menu descriptions translated
* Yet more small fixes

0.7:
*Remainder of text translated

0.8:
*Various localization/quality of life changes